/**
 * Configuração da URL base da API
 * 
 * Este arquivo determina qual URL será usada para conectar ao backend,
 * dependendo da plataforma (Web, Android, iOS) e do ambiente (dev/produção).
 * 
 * IMPORTANTE: Em dispositivos móveis físicos, NUNCA use "localhost"!
 * - localhost no dispositivo móvel aponta para o próprio dispositivo
 * - Você precisa usar o IP da sua máquina na rede local
 * - Exemplo: se seu computador está em 192.168.1.100, use esse IP
 */
import { Platform } from 'react-native';

/**
 * IP do servidor backend na rede local
 * 
 * COMO DESCOBRIR SEU IP:
 * - Windows: ipconfig (procure por "IPv4")
 * - Mac/Linux: ifconfig ou ip addr
 * - Ou acesse: https://whatismyipaddress.com/ (IP local)
 * 
 * IMPORTANTE: Altere este valor se seu IP mudar!
 */
const BACKEND_IP = '192.168.15.114';

/**
 * Porta onde o backend Spring Boot está rodando
 * (padrão do Spring Boot é 8080)
 */
const BACKEND_PORT = '8080';

/**
 * Função que retorna a URL base da API dependendo da plataforma
 * 
 * Por que diferentes URLs para diferentes plataformas?
 * 
 * 1. WEB (navegador):
 *    - Roda na mesma máquina que o backend
 *    - localhost funciona perfeitamente
 * 
 * 2. ANDROID (emulador):
 *    - 10.0.2.2 é um alias especial que aponta para localhost da máquina host
 *    - Mas dispositivos físicos precisam do IP real da rede
 * 
 * 3. ANDROID (dispositivo físico):
 *    - Precisa do IP da rede local (ex: 192.168.1.100)
 *    - Dispositivo e computador devem estar na mesma rede Wi-Fi
 * 
 * 4. iOS (simulador):
 *    - localhost funcionaria, mas usamos IP para consistência
 * 
 * 5. iOS (dispositivo físico):
 *    - SEMPRE precisa do IP da rede local
 * 
 * @returns {string} URL base da API (ex: http://192.168.15.114:8080)
 */
const getApiUrl = () => {
  // __DEV__ é uma variável global do React Native/Expo
  // true em desenvolvimento, false em produção
  if (__DEV__) {
    // ========== PLATAFORMA WEB ==========
    // Navegador roda na mesma máquina que o backend
    // localhost funciona porque está no mesmo computador
    if (Platform.OS === 'web') {
      return `http://localhost:${BACKEND_PORT}`;
    }
    
    // ========== PLATAFORMA ANDROID ==========
    // Emulador: 10.0.2.2 aponta para localhost da máquina host
    // Dispositivo físico: precisa do IP real da rede
    // Por segurança e consistência, sempre usamos o IP da rede
    if (Platform.OS === 'android') {
      return `http://${BACKEND_IP}:${BACKEND_PORT}`;
    }
    
    // ========== PLATAFORMA iOS ==========
    // Simulador: localhost funcionaria, mas usamos IP para consistência
    // Dispositivo físico: SEMPRE precisa do IP da rede
    if (Platform.OS === 'ios') {
      return `http://${BACKEND_IP}:${BACKEND_PORT}`;
    }
    
    // Fallback para qualquer outra plataforma
    // Sempre usa IP da rede para dispositivos móveis
    return `http://${BACKEND_IP}:${BACKEND_PORT}`;
  }
  
  // ========== PRODUÇÃO ==========
  // Em produção, use a URL do seu servidor hospedado
  // Exemplo: https://api.seudominio.com
  return 'https://seu-servidor.com';
};

/**
 * URL base da API exportada para uso em outros módulos
 * 
 * Esta constante é usada pelo albumService.js para fazer requisições HTTP.
 * 
 * Exemplo de valor: "http://192.168.15.114:8080"
 */
export const API_BASE_URL = getApiUrl();

/**
 * Logs de debug (apenas em desenvolvimento)
 * 
 * Estes logs aparecem no console quando o app inicia,
 * ajudando a verificar se a URL está configurada corretamente.
 */
if (__DEV__) {
  console.log('🔗 API Base URL:', API_BASE_URL);
  console.log('🌐 URL completa da API:', `${API_BASE_URL}/api/albuns`);
}

