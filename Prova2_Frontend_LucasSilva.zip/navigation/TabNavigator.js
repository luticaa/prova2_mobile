import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import React from 'react';

import { HapticTab } from '@/components/haptic-tab';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import AlbunsScreen from '@/screens/AlbunsScreen';
import HomeScreen from '@/screens/HomeScreen';

const Tab = createBottomTabNavigator();

/**
 * Tab Navigator - Navegação por abas na parte inferior
 * Substitui o sistema de tabs do Expo Router
 */
export default function TabNavigator() {
  const colorScheme = useColorScheme();

  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          backgroundColor: 'rgba(33, 37, 41, 0.95)',
          borderTopWidth: 0,
          elevation: 0,
          shadowOpacity: 0,
        },
        tabBarItemStyle: {
          flex: 1,
          maxWidth: '50%',
        },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <IconSymbol size={28} name="house.fill" color={color} />,
        }}
      />
      <Tab.Screen
        name="Albuns"
        component={AlbunsScreen}
        options={{
          title: 'Álbuns',
          tabBarIcon: ({ color }) => <MaterialIcons name="album" size={28} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

