import { DarkTheme, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import 'react-native-reanimated';

import { useColorScheme } from '@/hooks/use-color-scheme';
import TabNavigator from '@/navigation/TabNavigator';
import EditarAlbumScreen from '@/screens/EditarAlbumScreen';
import NovoAlbumScreen from '@/screens/NovoAlbumScreen';

const Stack = createNativeStackNavigator();

/**
 * Componente raiz da aplicação
 * Configura NavigationContainer e Stack Navigator
 */
export default function App() {
  const colorScheme = useColorScheme();

  return (
    <NavigationContainer
      theme={colorScheme === 'dark' ? DarkTheme : DefaultTheme}
    >
      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >
        {/* Tab Navigator (Home e Álbuns) */}
        <Stack.Screen name="Tabs" component={TabNavigator} />
        
        {/* Telas modais */}
        <Stack.Screen
          name="NovoAlbum"
          component={NovoAlbumScreen}
          options={{
            presentation: 'modal',
            title: 'Novo Álbum',
          }}
        />
        <Stack.Screen
          name="EditarAlbum"
          component={EditarAlbumScreen}
          options={{
            presentation: 'modal',
            title: 'Editar Álbum',
          }}
        />
      </Stack.Navigator>
      <StatusBar style="auto" />
    </NavigationContainer>
  );
}

