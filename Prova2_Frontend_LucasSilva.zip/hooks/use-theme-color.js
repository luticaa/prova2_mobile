/**
 * Learn more about light and dark modes:
 * https://docs.expo.dev/guides/color-schemes/
 */

import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';

/**
 * Hook para obter cores do tema baseado no esquema de cores atual (claro/escuro)
 * @param {Object} props - Propriedades com cores opcionais para modo claro e escuro
 * @param {string} [props.light] - Cor para modo claro
 * @param {string} [props.dark] - Cor para modo escuro
 * @param {string} colorName - Nome da cor do tema (deve existir em Colors.light e Colors.dark)
 * @returns {string} A cor apropriada baseada no tema atual
 */
export function useThemeColor(props, colorName) {
  const theme = useColorScheme() ?? 'light';
  const colorFromProps = props[theme];

  if (colorFromProps) {
    return colorFromProps;
  } else {
    return Colors[theme][colorName];
  }
}


