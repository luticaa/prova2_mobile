/**
 * Tela inicial (Home) da aplicação
 * Exibe uma tela de boas-vindas com imagem de fundo e botão para acessar a galeria de álbuns
 */
import { ThemedText } from '@/components/themed-text';
import React from 'react';
import { ImageBackground, StyleSheet, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function HomeScreen({ navigation }) {
  const handleEntrar = () => {
    navigation.navigate('Albuns');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ImageBackground
        source={require('@/assets/images/cramps.jpg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          <View style={styles.content}>
            <ThemedText type="title" style={styles.title}>
              LUTICA&apos;S SEBO
            </ThemedText>
            <ThemedText style={styles.subtitle}>
              Para os amantes de um bom som!
            </ThemedText>
            
            <TouchableOpacity
              style={styles.btnEntrar}
              onPress={handleEntrar}
              activeOpacity={0.8}
            >
              <ThemedText style={styles.btnText}>ENTRAR</ThemedText>
            </TouchableOpacity>
          </View>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    padding: 40,
    maxWidth: 400,
    width: '90%',
  },
  title: {
    fontSize: 32,
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 40,
    textAlign: 'center',
    opacity: 0.9,
  },
  btnEntrar: {
    width: '100%',
    paddingVertical: 16,
    paddingHorizontal: 32,
    backgroundColor: '#d32f2f',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  btnText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
});

