/**
 * Tela de Cadastro de Novo Álbum
 * 
 * Esta tela exibe um formulário para cadastrar um novo álbum.
 * Permite preencher:
 * - Título do álbum
 * - Nome da banda
 * - Ano de lançamento
 * - Gênero musical
 * - Preço
 * 
 * Após salvar com sucesso, redireciona para a lista de álbuns.
 */
import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  ImageBackground,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ThemedText } from '@/components/themed-text';
import { albumService } from '@/services/albumService';

/**
 * Componente da tela de cadastro
 */
export default function NovoAlbumScreen({ navigation }) {
  // navigation prop do React Navigation
  
  // Estado que controla o loading durante o envio do formulário
  const [loading, setLoading] = useState(false);
  
  // Estado que armazena os dados do formulário
  const [formData, setFormData] = useState({
    titulo: '',
    banda: '',
    ano: 0,
    genero: '',
    preco: 0,
  });

  /**
   * Handler chamado quando o usuário clica em "Salvar Álbum".
   * 
   * Fluxo:
   * 1. Valida se todos os campos obrigatórios estão preenchidos
   * 2. Ativa loading
   * 3. Envia dados para o backend via albumService.criar()
   * 4. Exibe mensagem de sucesso
   * 5. Redireciona para a lista de álbuns
   * 6. Trata erros caso ocorram
   */
  const handleSubmit = async () => {
    if (!formData.titulo || !formData.banda || !formData.genero || formData.ano <= 0 || formData.preco <= 0) {
      Alert.alert('Erro', 'Preencha todos os campos corretamente');
      return;
    }

    try {
      setLoading(true);
      await albumService.criar(formData);
      Alert.alert('Sucesso', 'Álbum criado com sucesso!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      Alert.alert('Erro', 'Erro ao criar álbum');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Renderiza o formulário de cadastro com:
   * - Background animado
   * - Campos de entrada para cada propriedade do álbum
   * - Botões Salvar e Cancelar
   * - Loading durante o envio
   */
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ImageBackground
        source={require('@/assets/images/keeperof7.webp')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          {/* 
            ScrollView permite rolar o formulário quando o teclado aparece.
            keyboardShouldPersistTaps="handled" mantém o teclado aberto ao tocar em botões.
          */}
          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.formContainer}>
              {/* Título da tela */}
              <ThemedText type="title" lightColor="#fff" darkColor="#fff" style={styles.title}>
                Cadastrar Novo Álbum
              </ThemedText>

              {/* ========== CAMPO: TÍTULO ========== */}
              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Título:</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.titulo}
                  // Atualiza apenas o campo 'titulo' mantendo os outros campos (spread operator)
                  onChangeText={(text) => setFormData({ ...formData, titulo: text })}
                  placeholder="Digite o título"
                  placeholderTextColor="#999"
                />
              </View>

              {/* ========== CAMPO: BANDA ========== */}
              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Banda:</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.banda}
                  onChangeText={(text) => setFormData({ ...formData, banda: text })}
                  placeholder="Digite a banda"
                  placeholderTextColor="#999"
                />
              </View>

              {/* ========== CAMPO: ANO ========== */}
              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Ano:</ThemedText>
                <TextInput
                  style={styles.input}
                  // Converte número para string para exibir no TextInput
                  value={formData.ano.toString()}
                  // Converte string para número (parseInt) ou usa 0 se inválido
                  onChangeText={(text) => setFormData({ ...formData, ano: parseInt(text) || 0 })}
                  placeholder="Digite o ano"
                  keyboardType="numeric" // Exibe teclado numérico no mobile
                  placeholderTextColor="#999"
                />
              </View>

              {/* ========== CAMPO: GÊNERO ========== */}
              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Gênero:</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.genero}
                  onChangeText={(text) => setFormData({ ...formData, genero: text })}
                  placeholder="Digite o gênero"
                  placeholderTextColor="#999"
                />
              </View>

              {/* ========== CAMPO: PREÇO ========== */}
              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Preço:</ThemedText>
                <TextInput
                  style={styles.input}
                  // Converte número para string
                  value={formData.preco.toString()}
                  // Converte string para número decimal (parseFloat) ou usa 0 se inválido
                  onChangeText={(text) => setFormData({ ...formData, preco: parseFloat(text) || 0 })}
                  placeholder="Digite o preço"
                  keyboardType="decimal-pad" // Teclado numérico com ponto decimal
                  placeholderTextColor="#999"
                />
              </View>

              {/* ========== BOTÃO SALVAR ========== */}
              <TouchableOpacity
                style={[styles.btn, styles.btnPrimary, loading && styles.btnDisabled]}
                onPress={handleSubmit}
                disabled={loading} // Desabilita botão durante o envio
              >
                {/* Exibe spinner durante loading, senão exibe texto */}
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <ThemedText style={styles.btnText}>Salvar Álbum</ThemedText>
                )}
              </TouchableOpacity>

              {/* ========== BOTÃO CANCELAR ========== */}
              <TouchableOpacity
                style={[styles.btn, styles.btnSecondary]}
                onPress={() => navigation.goBack()} // Volta para a tela anterior
              >
                <ThemedText style={styles.btnSecondaryText}>Cancelar</ThemedText>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 12,
    paddingBottom: 20,
  },
  formContainer: {
    width: '100%',
  },
  title: {
    textAlign: 'center',
    marginBottom: 16,
    fontSize: 24,
  },
  formGroup: {
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    marginBottom: 6,
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ced4da',
    borderRadius: 6,
    padding: 10,
    fontSize: 15,
    backgroundColor: '#fff',
    minHeight: 44,
  },
  btn: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: 6,
    minHeight: 44,
  },
  btnPrimary: {
    backgroundColor: '#0d6efd',
  },
  btnSecondary: {
    backgroundColor: '#6c757d',
    marginTop: 8,
  },
  btnDisabled: {
    opacity: 0.6,
  },
  btnText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  btnSecondaryText: {
    color: '#fff',
    fontSize: 15,
  },
});

