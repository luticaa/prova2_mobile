// app/albuns/[id].jsx
import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  ImageBackground,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ThemedText } from '@/components/themed-text';
import { albumService } from '@/services/albumService';

export default function EditarAlbumScreen({ navigation, route }) {
  const id = route.params?.id;
  const [loading, setLoading] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const [formData, setFormData] = useState({
    titulo: '',
    banda: '',
    ano: 0,
    genero: '',
    preco: 0,
  });

  useEffect(() => {
    if (id) {
      carregarAlbum();
    }
  }, [id]);

  const carregarAlbum = async () => {
    try {
      setCarregando(true);
      const album = await albumService.buscarPorId(Number(id));
      setFormData({
        titulo: album.titulo,
        banda: album.banda,
        ano: album.ano,
        genero: album.genero,
        preco: Number(album.preco),
      });
    } catch (error) {
      Alert.alert('Erro', 'Erro ao carregar álbum');
      navigation.goBack();
    } finally {
      setCarregando(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.titulo || !formData.banda || !formData.genero || formData.ano <= 0 || formData.preco <= 0) {
      Alert.alert('Erro', 'Preencha todos os campos corretamente');
      return;
    }

    try {
      setLoading(true);
      await albumService.atualizar(Number(id), formData);
      Alert.alert('Sucesso', 'Álbum editado com sucesso!', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      Alert.alert('Erro', 'Erro ao atualizar álbum');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (carregando) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <ImageBackground
          source={require('@/assets/images/kingCrimson.jpg')}
          style={styles.backgroundImage}
          resizeMode="cover"
        >
          <View style={[styles.overlay, { justifyContent: 'center', alignItems: 'center' }]}>
            <ActivityIndicator size="large" color="#fff" />
          </View>
        </ImageBackground>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ImageBackground
        source={require('@/assets/images/kingCrimson.jpg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.formContainer}>
              <ThemedText type="title" lightColor="#fff" darkColor="#fff" style={styles.title}>
                Editar Álbum
              </ThemedText>

              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Título</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.titulo}
                  onChangeText={(text) => setFormData({ ...formData, titulo: text })}
                  placeholder="Digite o título"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Banda</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.banda}
                  onChangeText={(text) => setFormData({ ...formData, banda: text })}
                  placeholder="Digite a banda"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Ano</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.ano.toString()}
                  onChangeText={(text) => setFormData({ ...formData, ano: parseInt(text) || 0 })}
                  placeholder="Digite o ano"
                  keyboardType="numeric"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Gênero</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.genero}
                  onChangeText={(text) => setFormData({ ...formData, genero: text })}
                  placeholder="Digite o gênero"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.formGroup}>
                <ThemedText lightColor="#fff" darkColor="#fff" style={styles.label}>Preço</ThemedText>
                <TextInput
                  style={styles.input}
                  value={formData.preco.toString()}
                  onChangeText={(text) => setFormData({ ...formData, preco: parseFloat(text) || 0 })}
                  placeholder="Digite o preço"
                  keyboardType="decimal-pad"
                  placeholderTextColor="#999"
                />
              </View>

              <TouchableOpacity
                style={[styles.btn, styles.btnSave, loading && styles.btnDisabled]}
                onPress={handleSubmit}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <ThemedText style={styles.btnText}>Salvar Alterações</ThemedText>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.btn, styles.btnSecondary]}
                onPress={() => navigation.goBack()}
              >
                <ThemedText style={styles.btnSecondaryText}>Cancelar</ThemedText>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  scrollContent: {
    flexGrow: 1,
    padding: 12,
    paddingBottom: 20,
  },
  formContainer: {
    width: '100%',
  },
  title: {
    marginBottom: 16,
    fontSize: 24,
  },
  formGroup: {
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    marginBottom: 6,
    fontWeight: '600',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ced4da',
    borderRadius: 6,
    padding: 10,
    fontSize: 15,
    backgroundColor: '#fff',
    minHeight: 44,
  },
  btn: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: 6,
    minHeight: 44,
  },
  btnSave: {
    backgroundColor: '#d32f2f',
  },
  btnSecondary: {
    backgroundColor: '#6c757d',
    marginTop: 8,
  },
  btnDisabled: {
    opacity: 0.6,
  },
  btnText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  btnSecondaryText: {
    color: '#fff',
    fontSize: 15,
  },
});

