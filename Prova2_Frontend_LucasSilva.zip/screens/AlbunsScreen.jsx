/**
 * Tela principal - Lista de Álbuns
 * 
 * Esta é a tela principal do aplicativo, exibindo todos os álbuns cadastrados
 * em um layout de grid (2 colunas). Permite:
 * - Visualizar lista de álbuns
 * - Buscar por nome da banda
 * - Editar álbum (ao tocar em um card)
 * - Excluir álbum (através do modal de ações)
 * - Pull-to-refresh (arrastar para baixo para atualizar)
 * 
 * Tecnologias usadas:
 * - React Hooks (useState, useEffect)
 * - React Navigation para navegação
 * - FlatList para renderização eficiente de listas
 * - Axios para requisições HTTP (através do albumService)
 */
import { ThemedText } from '@/components/themed-text';
import { API_BASE_URL } from '@/constants/api';
import { albumService } from '@/services/albumService';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { Image } from 'expo-image';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  ImageBackground,
  Modal,
  Platform,
  RefreshControl,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

/**
 * Componente principal da tela de álbuns
 * 
 * Gerencia o estado da lista, busca, loading e modais.
 */
export default function AlbunsScreen({ navigation }) {
  // navigation prop do React Navigation
  
  // ========== ESTADOS (State) ==========
  
  // Lista de álbuns exibidos na tela
  const [albuns, setAlbuns] = useState([]);
  
  // Controla exibição do loading inicial (quando a tela carrega pela primeira vez)
  const [loading, setLoading] = useState(true);
  
  // Controla exibição do loading durante pull-to-refresh
  const [refreshing, setRefreshing] = useState(false);
  
  // Texto digitado no campo de busca
  const [busca, setBusca] = useState('');
  
  // Controla visibilidade do modal de ações (editar/excluir)
  const [modalVisible, setModalVisible] = useState(false);
  
  // Álbum selecionado quando o usuário toca em um card
  const [albumSelecionado, setAlbumSelecionado] = useState(null);
  
  // Mensagem de sucesso temporária (ex: "Álbum excluído com sucesso!")
  const [mensagemSucesso, setMensagemSucesso] = useState(null);

  // ========== EFEITOS (Effects) ==========
  
  /**
   * useEffect executa quando o componente é montado (tela é aberta).
   * Carrega a lista de álbuns automaticamente ao abrir a tela.
   */
  useEffect(() => {
    carregarAlbuns();
  }, []); // Array vazio [] significa "executar apenas uma vez ao montar"

  /**
   * Função assíncrona que carrega os álbuns do backend.
   * 
   * @param {string} [filtro] - Nome da banda para filtrar os resultados (opcional)
   * 
   * Fluxo:
   * 1. Ativa loading
   * 2. Limpa espaços do filtro (se fornecido)
   * 3. Faz requisição HTTP para o backend
   * 4. Atualiza estado com os dados recebidos
   * 5. Trata erros (timeout, conexão, etc.)
   * 6. Desativa loading
   */
  const carregarAlbuns = async (filtro) => {
    try {
      setLoading(true);
      // Remove espaços extras do filtro
      const filtroLimpo = filtro?.trim() || undefined;
      console.log('🔄 Carregando álbuns...', filtroLimpo ? `Filtro: "${filtroLimpo}"` : 'Sem filtro');
      console.log('📱 Plataforma:', Platform.OS);
      console.log('🔗 API URL:', API_BASE_URL);
      
      const dados = await albumService.listar(filtroLimpo);
      console.log('📦 Álbuns recebidos:', dados.length, 'álbuns');
      console.log('✅ Dados:', JSON.stringify(dados, null, 2));
      setAlbuns(dados);
      if (filtroLimpo && dados.length === 0) {
        Alert.alert('Aviso', 'DESCULPE SUA BUSCA NAO RETORNOU RESULTADOS!');
      }
    } catch (err) {
      console.error('💥 Erro completo ao carregar álbuns:', JSON.stringify(err, null, 2));
      console.error('💥 Erro code:', err.code);
      console.error('💥 Erro message:', err.message);
      console.error('💥 Erro response:', err.response);
      console.error('💥 Erro request:', err.request);
      
      let mensagemErro = 'Erro ao carregar álbuns';
      
      if (err.code === 'ECONNABORTED' || err.message?.includes('timeout')) {
        mensagemErro = 'Timeout: O servidor demorou muito para responder. Verifique se o backend está rodando.';
      } else if (err.code === 'ECONNREFUSED' || err.message?.includes('Network Error') || err.message?.includes('Network request failed')) {
        mensagemErro = 'Erro de conexão: Não foi possível conectar ao servidor.\n\nVerifique:\n• Backend rodando na porta 8080\n• IP correto: 192.168.15.114:8080\n• Dispositivo na mesma rede Wi-Fi\n• Firewall não bloqueando\n\nTeste no navegador:\nhttp://192.168.15.114:8080/api/albuns';
      } else if (err.response) {
        mensagemErro = `Erro ${err.response.status}: ${err.response.data?.message || 'Erro ao carregar álbuns'}`;
      } else if (err.request) {
        mensagemErro = 'Sem resposta do servidor. Verifique se o backend está rodando e acessível.';
      }
      
      Alert.alert('Erro de Conexão', mensagemErro);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // ========== HANDLERS (Funções de Evento) ==========
  
  /**
   * Handler chamado quando o usuário pressiona Enter no campo de busca
   * ou clica no botão de buscar.
   * 
   * Se houver texto na busca, filtra por banda.
   * Se estiver vazio, lista todos os álbuns.
   */
  const handleBuscar = () => {
    const buscaLimpa = busca.trim();
    if (buscaLimpa) {
      carregarAlbuns(buscaLimpa);
    } else {
      carregarAlbuns();
    }
  };

  /**
   * Limpa o campo de busca e recarrega todos os álbuns.
   */
  const handleLimparFiltro = () => {
    setBusca('');
    carregarAlbuns();
  };

  /**
   * Atualiza o estado de busca conforme o usuário digita.
   * 
   * @param {string} text - Texto digitado no campo de busca
   */
  const handleBuscaChange = (text) => {
    setBusca(text);
  };

  /**
   * Handler para excluir um álbum.
   * 
   * Exibe um Alert de confirmação antes de excluir.
   * Se confirmado, chama o serviço para excluir e recarrega a lista.
   * 
   * @param {number} id - ID do álbum a ser excluído
   */
  const handleExcluir = async (id) => {
    Alert.alert(
      'Confirmar Exclusão',
      'Tem certeza que deseja excluir este álbum?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await albumService.excluir(id);
              setMensagemSucesso('Álbum excluído com sucesso!');
              setTimeout(() => setMensagemSucesso(null), 3000);
              const buscaLimpa = busca.trim();
              carregarAlbuns(buscaLimpa || undefined);
              setModalVisible(false);
            } catch {
              Alert.alert('Erro', 'Erro ao excluir álbum');
            }
          },
        },
      ]
    );
  };

  /**
   * Abre o modal de ações (editar/excluir) quando o usuário toca em um card.
   * 
   * @param {Object} album - Álbum selecionado pelo usuário
   */
  const abrirModal = (album) => {
    setAlbumSelecionado(album);
    setModalVisible(true);
  };

  /**
   * Retorna a imagem padrão para todos os álbuns.
   * 
   * Por enquanto, todos os álbuns usam a mesma imagem (colcheia.jpg).
   * Futuramente, cada álbum poderia ter sua própria capa.
   */
  const getAlbumImage = () => {
    return require('@/assets/images/colcheia.jpg');
  };

  /**
   * Função de renderização de cada item da lista.
   * 
   * FlatList chama esta função para cada álbum na lista.
   * Retorna um componente TouchableOpacity (card clicável) com:
   * - Imagem do álbum
   * - Título, banda, ano e preço
   * 
   * @param {Object} param0 - Objeto com o item fornecido pelo FlatList
   * @param {Object} param0.item - Álbum a ser renderizado
   */
  const renderItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.card}
      onPress={() => abrirModal(item)}
      activeOpacity={0.8}
    >
      <Image
        source={getAlbumImage()}
        style={styles.albumImg}
        contentFit="contain"
      />
      <View style={styles.albumInfo}>
        <ThemedText type="defaultSemiBold" style={styles.albumTitle} lightColor="#fff" darkColor="#fff" numberOfLines={1}>
          {item.titulo}
        </ThemedText>
        <ThemedText type="defaultSemiBold" style={styles.albumBanda} lightColor="#fff" darkColor="#fff" numberOfLines={1}>
          {item.banda}
        </ThemedText>
        <ThemedText type="defaultSemiBold" style={styles.albumAno} lightColor="#fff" darkColor="#fff">
          {item.ano}
        </ThemedText>
        <ThemedText type="defaultSemiBold" style={styles.albumPreco} lightColor="#000" darkColor="#000">
          R$ {item.preco.toFixed(2)}
        </ThemedText>
      </View>
    </TouchableOpacity>
  );

  // ========== RENDERIZAÇÃO ==========
  
  /**
   * Renderiza tela de loading enquanto os dados são carregados pela primeira vez.
   * 
   * Exibe um spinner centralizado sobre o background animado.
   * Só aparece no carregamento inicial, não durante pull-to-refresh.
   */
  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <ImageBackground
          source={require('@/assets/images/alice.gif')}
          style={styles.backgroundImage}
          resizeMode="cover"
        >
          <View style={[styles.overlay, { justifyContent: 'center', alignItems: 'center' }]}>
            <ActivityIndicator size="large" color="#fff" />
          </View>
        </ImageBackground>
      </SafeAreaView>
    );
  }

  /**
   * Renderiza a tela principal com:
   * - Navbar com botões Home, Novo e campo de busca
   * - Lista de álbuns em grid (2 colunas)
   * - Modal de ações (editar/excluir)
   * - Mensagens de sucesso temporárias
   */
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ImageBackground
        source={require('@/assets/images/alice.gif')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          {/* ========== NAVBAR ========== */}
          {/* Barra de navegação superior com botões e busca */}
          <View style={styles.navbar}>
            {/* Primeira linha: Botões Home e Cadastrar */}
            <View style={styles.navbarTop}>
              {/* Botão Home - navega para a tela inicial */}
              <TouchableOpacity 
                style={styles.btnHome}
                onPress={() => navigation.navigate('Home')}
              >
                <ThemedText style={styles.btnHomeText}>🏠 Home</ThemedText>
              </TouchableOpacity>
              {/* Botão Novo - navega para tela de cadastro */}
              <TouchableOpacity 
                style={styles.btnCadastrar}
                onPress={() => navigation.getParent()?.navigate('NovoAlbum')}
              >
                <ThemedText style={styles.btnCadastrarText}>➕ Novo</ThemedText>
              </TouchableOpacity>
            </View>
            
            {/* Segunda linha: Campo de busca e botões de ação */}
            <View style={styles.navbarSearch}>
              <TextInput
                style={styles.inputBusca}
                placeholder="Buscar por banda..."
                placeholderTextColor="#999"
                value={busca}
                onChangeText={handleBuscaChange}
                onSubmitEditing={handleBuscar}
              />
              <View style={styles.searchButtons}>
                <TouchableOpacity style={styles.btnBuscar} onPress={handleBuscar}>
                  <ThemedText style={styles.btnBuscarText}>🔍</ThemedText>
                </TouchableOpacity>
                {busca.length > 0 && (
                  <TouchableOpacity style={styles.btnLimpar} onPress={handleLimparFiltro}>
                    <ThemedText style={styles.btnLimparText}>✕</ThemedText>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </View>

          {/* ========== MENSAGENS DE SUCESSO ========== */}
          {/* Exibe mensagem temporária quando uma ação é bem-sucedida (ex: exclusão) */}
          {mensagemSucesso && (
            <View style={styles.alertSuccess}>
              <ThemedText style={styles.alertSuccessText}>{mensagemSucesso}</ThemedText>
            </View>
          )}

          {/* ========== LISTA DE ÁLBUNS ========== */}
          {/* 
            FlatList renderiza a lista de álbuns de forma eficiente:
            - numColumns={2} → layout de grid com 2 colunas
            - renderItem → função que renderiza cada card
            - keyExtractor → identifica cada item (usa o ID)
            - refreshControl → permite pull-to-refresh (arrastar para baixo)
            - contentContainerStyle → padding para espaçamento
          */}
          <FlatList
            data={albuns}
            renderItem={renderItem}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.listContainer}
            numColumns={2}
            columnWrapperStyle={styles.row}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => {
                setRefreshing(true);
                const buscaLimpa = busca.trim();
                carregarAlbuns(buscaLimpa || undefined);
              }} />
            }
          />
        </View>
      </ImageBackground>

      {/* ========== MODAL DE AÇÕES ========== */}
      {/* 
        Modal que aparece quando o usuário toca em um card de álbum.
        Permite escolher entre Editar ou Excluir o álbum.
        
        Props:
        - visible: controla se o modal está visível
        - transparent: fundo transparente (overlay escuro)
        - animationType: animação de entrada/saída
        - onRequestClose: chamado quando usuário pressiona botão voltar (Android)
      */}
      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText type="subtitle" lightColor="#fff" darkColor="#fff" style={styles.modalTitle}>
                O que deseja fazer?
              </ThemedText>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <MaterialIcons name="close" size={24} color="#fff" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <ThemedText lightColor="#fff" darkColor="#fff">
                Escolha uma ação para o álbum <ThemedText type="defaultSemiBold" lightColor="#fff" darkColor="#fff">{albumSelecionado?.titulo}</ThemedText>.
              </ThemedText>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalBtn}
                onPress={() => {
                  setModalVisible(false);
                  navigation.getParent()?.navigate('EditarAlbum', { id: albumSelecionado?.id });
                }}
              >
                <ThemedText style={styles.modalBtnText}>Editar</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, styles.modalBtnDanger]}
                onPress={() => albumSelecionado && handleExcluir(albumSelecionado.id)}
              >
                <ThemedText style={styles.modalBtnText}>Excluir</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, styles.modalBtnCancel]}
                onPress={() => setModalVisible(false)}
              >
                <ThemedText style={styles.modalBtnText}>Cancelar</ThemedText>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

/**
 * Estilos da tela usando StyleSheet do React Native.
 * 
 * StyleSheet.create() otimiza os estilos e valida em tempo de compilação.
 * Melhor performance que objetos JavaScript inline.
 */
const styles = StyleSheet.create({
  // Container principal ocupa toda a tela
  container: {
    flex: 1,
  },
  // Imagem de fundo animada (GIF)
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  // Overlay escuro semi-transparente sobre a imagem de fundo
  // Melhora legibilidade do texto
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.3)', // 30% de opacidade preta
  },
  navbar: {
    backgroundColor: '#212529',
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  navbarTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  btnHome: {
    backgroundColor: '#495057',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
  },
  btnHomeText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  btnCadastrar: {
    backgroundColor: '#28a745',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
  },
  btnCadastrarText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  navbarSearch: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  inputBusca: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    fontSize: 16,
    minHeight: 44,
  },
  searchButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  btnBuscar: {
    backgroundColor: '#007bff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    minWidth: 44,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnBuscarText: {
    color: '#fff',
    fontSize: 18,
  },
  btnLimpar: {
    backgroundColor: '#dc3545',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    minWidth: 44,
    minHeight: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnLimparText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  alertSuccess: {
    backgroundColor: '#d4edda',
    padding: 12,
    margin: 16,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#c3e6cb',
  },
  alertSuccessText: {
    color: '#155724',
  },
  listContainer: {
    padding: 8,
    paddingBottom: 80, // Espaço para a barra de tabs
  },
  row: {
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  card: {
    backgroundColor: '#0077BE', // Azul oceano - preenche todo o card
    borderRadius: 12,
    padding: 8,
    marginBottom: 12,
    width: '48%',
    borderWidth: 3,
    borderColor: '#0077BE', // Azul oceano - borda ao redor de todo o card
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
  },
  albumImg: {
    width: '100%',
    height: 120,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#f8f9fa',
  },
  albumInfo: {
    gap: 4,
  },
  albumTitle: {
    fontSize: 14,
    marginBottom: 2,
  },
  albumBanda: {
    fontSize: 12,
    opacity: 0.8,
    marginBottom: 2,
  },
  albumAno: {
    fontSize: 11,
    opacity: 0.6,
    marginBottom: 4,
  },
  albumPreco: {
    fontSize: 14,
    color: '#000', // Preto
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#343a40',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    maxWidth: 400,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    color: '#fff',
  },
  modalBody: {
    marginBottom: 16,
  },
  modalFooter: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  modalBtn: {
    backgroundColor: '#0d6efd',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 4,
    flex: 1,
    minWidth: 80,
    alignItems: 'center',
  },
  modalBtnDanger: {
    backgroundColor: '#dc3545',
  },
  modalBtnCancel: {
    backgroundColor: '#6c757d',
  },
  modalBtnText: {
    color: '#fff',
    fontSize: 14,
  },
});

