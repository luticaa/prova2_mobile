// metro.config.js
const { getDefaultConfig } = require('expo/metro-config');

/** @type {import('expo/metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

// Configuração para suportar o alias @
config.resolver.alias = {
  '@': __dirname,
};

module.exports = config;

