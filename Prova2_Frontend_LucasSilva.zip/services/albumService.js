/**
 * Serviço de comunicação com a API de álbuns
 * 
 * Este módulo encapsula todas as chamadas HTTP para o backend Spring Boot.
 * Usa Axios como cliente HTTP para fazer requisições REST.
 * 
 * Benefícios desta abstração:
 * - Centraliza configuração de requisições (URL base, headers, timeout)
 * - Facilita manutenção (mudanças na API em um único lugar)
 * - Trata erros de forma consistente
 */
import { API_BASE_URL } from '@/constants/api';
import axios from 'axios';

/**
 * Instância do Axios configurada com:
 * - URL base da API (ex: http://192.168.15.114:8080/api)
 * - Headers padrão (Content-Type: application/json)
 * - Timeout de 15 segundos (evita requisições travadas)
 * 
 * Esta instância é reutilizada em todas as chamadas HTTP.
 */
const api = axios.create({
  baseURL: `${API_BASE_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000, // 15 segundos - se não houver resposta, cancela a requisição
});

/**
 * Objeto exportado contendo todos os métodos para interagir com a API de álbuns.
 * Cada método corresponde a um endpoint do backend.
 */
export const albumService = {
  /**
   * Lista todos os álbuns ou filtra por banda.
   * 
   * @param {string} [banda] - Nome da banda para filtrar os resultados (opcional)
   * @returns {Promise<Array>} Promise com array de álbuns
   * 
   * Exemplos de uso:
   * - albumService.listar() → GET /api/albuns (todos os álbuns)
   * - albumService.listar("Metallica") → GET /api/albuns?banda=Metallica
   */
  listar: async (banda) => {
    // Se banda foi fornecida, adiciona como query parameter
    // Caso contrário, params fica vazio e retorna todos os álbuns
    const params = banda ? { banda } : {};
    
    // Faz requisição GET para /api/albuns com parâmetros opcionais
    const response = await api.get('/albuns', { params });
    
    // Retorna apenas os dados (response.data), não o objeto response completo
    return response.data;
  },

  /**
   * Busca um álbum específico pelo seu ID.
   * 
   * @param {number} id - ID numérico do álbum
   * @returns {Promise<Object>} Promise com dados do álbum
   * 
   * Exemplo: albumService.buscarPorId(1) → GET /api/albuns/1
   */
  buscarPorId: async (id) => {
    // Template string para construir URL dinâmica: /api/albuns/{id}
    const response = await api.get(`/albuns/${id}`);
    return response.data;
  },

  /**
   * Cria um novo álbum no banco de dados.
   * 
   * @param {Object} album - Objeto com os dados do novo álbum (sem ID)
   * @param {string} album.titulo - Título do álbum
   * @param {string} album.banda - Nome da banda
   * @param {number} album.ano - Ano de lançamento
   * @param {string} album.genero - Gênero musical
   * @param {number} album.preco - Preço do álbum
   * @returns {Promise<Object>} Promise com o álbum criado incluindo o ID gerado
   * 
   * Exemplo:
   * albumService.criar({
   *   titulo: "Master of Puppets",
   *   banda: "Metallica",
   *   ano: 1986,
   *   genero: "Thrash Metal",
   *   preco: 89.90
   * })
   * → POST /api/albuns
   */
  criar: async (album) => {
    // POST envia o objeto album no corpo da requisição (JSON)
    // O backend valida e cria o registro, retornando com ID preenchido
    const response = await api.post('/albuns', album);
    return response.data;
  },

  /**
   * Atualiza um álbum existente.
   * 
   * @param {number} id - ID do álbum a ser atualizado
   * @param {Object} album - Objeto com os novos dados
   * @returns {Promise<Object>} Promise com o álbum atualizado
   * 
   * Exemplo:
   * albumService.atualizar(1, { titulo: "Novo Título", ... })
   * → PUT /api/albuns/1
   */
  atualizar: async (id, album) => {
    // PUT envia o objeto album no corpo e o ID na URL
    // O backend atualiza o registro existente
    const response = await api.put(`/albuns/${id}`, album);
    return response.data;
  },

  /**
   * Exclui um álbum do banco de dados.
   * 
   * @param {number} id - ID do álbum a ser excluído
   * @returns {Promise<void>} Promise vazia - operação bem-sucedida se não lançar erro
   * 
   * Exemplo: albumService.excluir(1) → DELETE /api/albuns/1
   */
  excluir: async (id) => {
    // DELETE não retorna dados, apenas status HTTP 204 (No Content)
    // Se houver erro (álbum não encontrado), Axios lança exceção
    await api.delete(`/albuns/${id}`);
  },
};

