import { StyleSheet, Text } from 'react-native';

import { useThemeColor } from '@/hooks/use-theme-color';

/**
 * Componente de texto que se adapta automaticamente ao tema (claro/escuro)
 * @param {Object} props - Propriedades do componente
 * @param {Object} [props.style] - Estilos adicionais para o texto
 * @param {string} [props.lightColor] - Cor do texto no modo claro
 * @param {string} [props.darkColor] - Cor do texto no modo escuro
 * @param {string} [props.type] - Tipo de texto: 'default', 'title', 'defaultSemiBold', 'subtitle', 'link'
 * @param {Object} props.rest - Outras propriedades do componente Text do React Native
 */
export function ThemedText({
  style,
  lightColor,
  darkColor,
  type = 'default',
  ...rest
}) {
  const color = useThemeColor({ light: lightColor, dark: darkColor }, 'text');

  return (
    <Text
      style={[
        { color },
        type === 'default' ? styles.default : undefined,
        type === 'title' ? styles.title : undefined,
        type === 'defaultSemiBold' ? styles.defaultSemiBold : undefined,
        type === 'subtitle' ? styles.subtitle : undefined,
        type === 'link' ? styles.link : undefined,
        style,
      ]}
      {...rest}
    />
  );
}

const styles = StyleSheet.create({
  default: {
    fontSize: 16,
    lineHeight: 24,
  },
  defaultSemiBold: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '600',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    lineHeight: 32,
  },
  subtitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  link: {
    lineHeight: 30,
    fontSize: 16,
    color: '#0a7ea4',
  },
});


