import { SymbolView } from 'expo-symbols';

/**
 * Componente de ícone usando SF Symbols nativo do iOS
 * Este componente é usado apenas no iOS, enquanto o icon-symbol.jsx é usado como fallback
 * @param {Object} props - Propriedades do componente
 * @param {string} props.name - Nome do símbolo SF
 * @param {number} [props.size=24] - Tamanho do ícone
 * @param {string} props.color - Cor do ícone
 * @param {Object} [props.style] - Estilos adicionais
 * @param {string} [props.weight='regular'] - Peso do símbolo
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
  weight = 'regular',
}) {
  return (
    <SymbolView
      weight={weight}
      tintColor={color}
      resizeMode="scaleAspectFit"
      name={name}
      style={[
        {
          width: size,
          height: size,
        },
        style,
      ]}
    />
  );
}


