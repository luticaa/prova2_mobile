import { View } from 'react-native';

import { useThemeColor } from '@/hooks/use-theme-color';

/**
 * Componente de view que se adapta automaticamente ao tema (claro/escuro)
 * @param {Object} props - Propriedades do componente
 * @param {Object} [props.style] - Estilos adicionais para a view
 * @param {string} [props.lightColor] - Cor de fundo no modo claro
 * @param {string} [props.darkColor] - Cor de fundo no modo escuro
 * @param {Object} props.otherProps - Outras propriedades do componente View do React Native
 */
export function ThemedView({ style, lightColor, darkColor, ...otherProps }) {
  const backgroundColor = useThemeColor({ light: lightColor, dark: darkColor }, 'background');

  return <View style={[{ backgroundColor }, style]} {...otherProps} />;
}


