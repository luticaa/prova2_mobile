package com.exercicioPratico.LabProgramacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabProgramacaoApplication {
	
	// Função principal que roda a aplicação
	public static void main(String[] args) {
		SpringApplication.run(LabProgramacaoApplication.class, args);
	}
}